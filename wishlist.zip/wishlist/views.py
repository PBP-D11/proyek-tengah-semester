
from multiprocessing import context
from webbrowser import get
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.http import HttpRequest, HttpResponse, HttpResponseNotFound, HttpResponseRedirect, JsonResponse
from django.urls import reverse
from wishlist.forms import *
from wishlist.models import *
from home.models import CustomUser
from django.views.decorators.csrf import csrf_exempt
from wishlist.forms import *
import datetime


# @login_required(login_url='/account/login/')
@csrf_exempt
def create_car_ajax(request):
    if request.method == 'POST':
        form = CarForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            price = form.cleaned_data.get('price')
            picture = form.cleaned_data.get('picture')
            car = Car.objects.create(name=name, price=price, picture=picture)
            car.save()
            context = {
                'pk': car.pk,
                'fields': {
                    'name': car.name,
                    'price': car.price,
                    'picture': car.picture
                }
            }
            return JsonResponse(context)
        return JsonResponse({'error': True})


@csrf_exempt
def delete_car_ajax(request, id):
    if (request.method == 'DELETE'):
        Car.objects.filter(id=id).delete()
        return HttpResponse(status=202)


def show_json_car(request):
    data_diary = Car.objects.all()
    return HttpResponse(serializers.serialize("json", data_diary), content_type="application/json")


def show_car(request):
    modelCar = Car.objects.all()
    form = CarForm()
    context = {
        'data': modelCar,
        'form': form,
    }
    return render(request, 'wishlist.html', context)
